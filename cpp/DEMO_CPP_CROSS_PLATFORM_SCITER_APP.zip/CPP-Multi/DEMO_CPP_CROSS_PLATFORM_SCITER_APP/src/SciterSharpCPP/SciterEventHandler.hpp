//
//  SciterEventHandler.hpp
//  DEMO_CPP_CROSS_PLATFORM_SCITER_APP
//
//  Created by Ramon Mendes on 09/04/17.
//  Copyright © 2017 MI Software. All rights reserved.
//

#pragma once

#include "sciter-x-behavior.h"


class SciterEventHandler : public sciter::event_handler
{
};
