#pragma once


class Consts
{
public:
	static constexpr auto AppName = WSTR("DEMO_CPP_CROSS_PLATFORM_SCITER_APP");
	static constexpr auto AppVersion = WSTR("1.0");
	static constexpr int AppVersionInt = 0x00010000;
};
