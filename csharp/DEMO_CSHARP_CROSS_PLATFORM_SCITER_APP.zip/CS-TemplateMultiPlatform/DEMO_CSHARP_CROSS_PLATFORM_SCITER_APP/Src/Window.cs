using System;
using SciterSharp;

namespace DEMO_CSHARP_CROSS_PLATFORM_SCITER_APP
{
	public class Window : SciterWindow
	{
		public Window()
		{
			var wnd = this;
			wnd.CreateMainWindow(800, 600);
			wnd.CenterTopLevelWindow();
			wnd.Title = "DEMO_CSHARP_CROSS_PLATFORM_SCITER_APP";
			#if WINDOWS
			wnd.Icon = Properties.Resources.IconMain;
			#endif
		}
	}
}